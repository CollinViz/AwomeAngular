import { ProvideParentFormDirective } from './provide-parent-form.directive';

describe('ProvideParentFormDirective', () => {
  it('should create an instance', () => {
    const directive = new ProvideParentFormDirective();
    expect(directive).toBeTruthy();
  });
});
