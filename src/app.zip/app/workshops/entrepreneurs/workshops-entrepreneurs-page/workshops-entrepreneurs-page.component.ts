import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workshops-entrepreneurs-page',
  templateUrl: './workshops-entrepreneurs-page.component.html',
  styles: []
})
export class WorkshopsEntrepreneursPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
