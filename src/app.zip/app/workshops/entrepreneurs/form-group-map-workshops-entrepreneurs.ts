export class FormGroupMapWorkshopsEntrepreneurs {
}
