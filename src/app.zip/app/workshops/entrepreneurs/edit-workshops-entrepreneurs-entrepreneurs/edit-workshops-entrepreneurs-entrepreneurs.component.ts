import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-workshops-entrepreneurs-entrepreneurs',
  templateUrl: './edit-workshops-entrepreneurs-entrepreneurs.component.html',
  styles: []
})
export class EditWorkshopsEntrepreneursEntrepreneursComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
