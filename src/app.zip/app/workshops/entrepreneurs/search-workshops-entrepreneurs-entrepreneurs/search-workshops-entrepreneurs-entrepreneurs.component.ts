import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-workshops-entrepreneurs-entrepreneurs',
  templateUrl: './search-workshops-entrepreneurs-entrepreneurs.component.html',
  styles: []
})
export class SearchWorkshopsEntrepreneursEntrepreneursComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
