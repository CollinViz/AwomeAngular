import { CardHeaderCssFormGroupDirective } from './card-header-css-form-group.directive';

describe('CardHeaderCssFormGroupDirective', () => {
  it('should create an instance', () => {
    const directive = new CardHeaderCssFormGroupDirective();
    expect(directive).toBeTruthy();
  });
});
