import { CardCssFormGroupDirective } from './card-css-form-group.directive';

describe('CardCssFormGroupDirective', () => {
  it('should create an instance', () => {
    const directive = new CardCssFormGroupDirective();
    expect(directive).toBeTruthy();
  });
});
