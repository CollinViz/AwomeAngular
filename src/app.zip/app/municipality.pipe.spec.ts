import { MunicipalityPipe } from './municipality.pipe';

describe('MunicipalityPipe', () => {
  it('create an instance', () => {
    const pipe = new MunicipalityPipe();
    expect(pipe).toBeTruthy();
  });
});
