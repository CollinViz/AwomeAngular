import { MainPlacePipe } from './main-place.pipe';

describe('MainPlacePipe', () => {
  it('create an instance', () => {
    const pipe = new MainPlacePipe();
    expect(pipe).toBeTruthy();
  });
});
