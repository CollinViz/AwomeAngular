import { DistrictMetroPipe } from './district-metro.pipe';

describe('DistrictMetroPipe', () => {
  it('create an instance', () => {
    const pipe = new DistrictMetroPipe();
    expect(pipe).toBeTruthy();
  });
});
