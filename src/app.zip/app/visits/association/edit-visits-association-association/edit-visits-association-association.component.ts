import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-visits-association-association',
  templateUrl: './edit-visits-association-association.component.html',
  styles: []
})
export class EditVisitsAssociationAssociationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
