export class FormGroupMapVisitsAssociation {
}
