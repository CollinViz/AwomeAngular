import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-visits-association-association',
  templateUrl: './search-visits-association-association.component.html',
  styles: []
})
export class SearchVisitsAssociationAssociationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
