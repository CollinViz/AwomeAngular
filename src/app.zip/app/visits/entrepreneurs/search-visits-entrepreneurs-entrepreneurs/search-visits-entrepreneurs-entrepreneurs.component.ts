import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-visits-entrepreneurs-entrepreneurs',
  templateUrl: './search-visits-entrepreneurs-entrepreneurs.component.html',
  styles: []
})
export class SearchVisitsEntrepreneursEntrepreneursComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
