export class FormGroupMapVisitsEntrepreneurs {
}
