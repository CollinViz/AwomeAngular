import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visits-entrepreneurs-page',
  templateUrl: './visits-entrepreneurs-page.component.html',
  styles: []
})
export class VisitsEntrepreneursPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
