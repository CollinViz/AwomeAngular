import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-visits-entrepreneurs-entrepreneurs',
  templateUrl: './edit-visits-entrepreneurs-entrepreneurs.component.html',
  styles: []
})
export class EditVisitsEntrepreneursEntrepreneursComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
