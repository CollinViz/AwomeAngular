import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-visits-enterprise-enterprise',
  templateUrl: './search-visits-enterprise-enterprise.component.html',
  styles: []
})
export class SearchVisitsEnterpriseEnterpriseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
