import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-visits-cooperative-cooperative',
  templateUrl: './search-visits-cooperative-cooperative.component.html',
  styles: []
})
export class SearchVisitsCooperativeCooperativeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
