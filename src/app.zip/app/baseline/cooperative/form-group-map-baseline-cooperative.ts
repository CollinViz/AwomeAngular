export class FormGroupMapBaselineCooperative {
}
