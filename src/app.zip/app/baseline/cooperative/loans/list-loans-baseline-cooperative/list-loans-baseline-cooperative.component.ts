import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-loans-baseline-cooperative',
  templateUrl: './list-loans-baseline-cooperative.component.html',
  styleUrls: ['./list-loans-baseline-cooperative.component.css']
})
export class ListLoansBaselineCooperativeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
