import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-loans-baseline-cooperative',
  templateUrl: './edit-loans-baseline-cooperative.component.html',
  styleUrls: ['./edit-loans-baseline-cooperative.component.css']
})
export class EditLoansBaselineCooperativeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
