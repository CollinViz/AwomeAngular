export class FormGroupMapBaselineEntrepreneur {
}
