export class FormGroupMapBaselineAssociation {
}
