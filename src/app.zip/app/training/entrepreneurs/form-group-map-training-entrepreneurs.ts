export class FormGroupMapTrainingEntrepreneurs {
}
