import { FixboolYNPipe } from './fixbool-yn.pipe';

describe('FixboolYNPipe', () => {
  it('create an instance', () => {
    const pipe = new FixboolYNPipe();
    expect(pipe).toBeTruthy();
  });
});
