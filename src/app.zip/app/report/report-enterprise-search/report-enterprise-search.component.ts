import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-enterprise-search',
  templateUrl: './report-enterprise-search.component.html',
  styleUrls: ['./report-enterprise-search.component.css']
})
export class ReportEnterpriseSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
