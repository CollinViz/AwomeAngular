import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrepreneur-income',
  templateUrl: './entrepreneur-income.component.html',
  styleUrls: ['./entrepreneur-income.component.css']
})
export class EntrepreneurIncomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
