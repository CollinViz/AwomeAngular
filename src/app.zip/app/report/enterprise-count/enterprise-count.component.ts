import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enterprise-count',
  templateUrl: './enterprise-count.component.html',
  styleUrls: ['./enterprise-count.component.css']
})
export class EnterpriseCountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
