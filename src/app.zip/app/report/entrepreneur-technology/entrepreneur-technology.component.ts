import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrepreneur-technology',
  templateUrl: './entrepreneur-technology.component.html',
  styleUrls: ['./entrepreneur-technology.component.css']
})
export class EntrepreneurTechnologyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
