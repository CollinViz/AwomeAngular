import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrepreneur-support',
  templateUrl: './entrepreneur-support.component.html',
  styleUrls: ['./entrepreneur-support.component.css']
})
export class EntrepreneurSupportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
