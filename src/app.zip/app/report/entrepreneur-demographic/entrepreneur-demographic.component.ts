import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrepreneur-demographic',
  templateUrl: './entrepreneur-demographic.component.html',
  styleUrls: ['./entrepreneur-demographic.component.css']
})
export class EntrepreneurDemographicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
